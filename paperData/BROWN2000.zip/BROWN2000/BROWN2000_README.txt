This BROWN2000_readme.txt file was generated on 20221130 by Fabien Margairaz, University of Utah

-------------------
GENERAL INFORMATION
-------------------

- Title of Dataset 
MEAN FLOW AND TURBULENCE MEASUREMENTS AROUND A 2-D ARRAY OF BUILDINGS IN A WIND TUNNEL

- Author Information
MICHAEL J. BROWN, ROBERT E. LAWSON, DAVID S. DECROIX, ROBERT L. LEE

- Date of data collection
2000

- Geographic location of data collection  
EPA Meteorological Wind Tunnel
Environmental Sciences Research Laboratory
U.S. Environmental Protection Agency
Research Triangle Park, NC 27711

- Curated at the University of Utah as dataset for
Fabien Margairaz, Balwinder Singh, Jeremy A. Gibbs, Loren Atwood, Eric R. Pardyjak, and Rob Stoll, [DATE TBD]. QES-Plume v1.0: A Lagrangian dispersion model. [JOURNAL NAME TBD].[DOI TBD]

- Contact Information at the University of Utah:
	Name: Fabien Margairaz
	Institution: Department of Mechanical Engineering, University of Utah
	Address: 1495 E 100 S, Salt Lake City, Utah 84112 USA
	Email: fabien.margairaz@utah.edu

- Description of methods used for collection/generation of data: 
Brown, M. J., R E. Lawson Jr., D. S. DeCroix, AND R. L. Lee. MEAN FLOW AND TURBULENCE MEASUREMENTS AROUND A 2-D ARRAY OF BUILDINGS IN A WIND TUNNEL. Presented at 11th Joint Conference on the Applications of Air Pollution Meteorology with the AWMA, Long Beach, CA, January 9-14, 2000.


---------------------
DATA & FILE OVERVIEW
---------------------

- Description of the dataset and files:
1.original_report: contains the original draft of the report from the EPA team and description of the location of measurements.

2.raw_data: raw data in .txt from the EPA team in 2000
 3DU.txt: u-velocity	
 3DV.txt: v-velocity	
 3DW.txt: w-velocity
 LatConc.txt: lateral concentration	
 SurfConc.txt: surface concentration	
 VertConc.txt: vertical concentration

3.process_data: contains process data in .mat, processed by Fabien Margairaz at the University of Utah in 2022. 
 flow.mat: 3D velocity and turbulence field. 
 LatConc.mat: lateral concentration
 VertConc.mat: vertical concentration
